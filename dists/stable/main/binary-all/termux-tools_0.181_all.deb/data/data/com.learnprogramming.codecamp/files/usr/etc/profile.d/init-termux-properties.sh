if [ ! -f /data/data/com.learnprogramming.codecamp/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.learnprogramming.codecamp/files/home/.termux/termux.properties ]; then
mkdir -p /data/data/com.learnprogramming.codecamp/files/home/.termux
cp /data/data/com.learnprogramming.codecamp/files/usr/share/examples/termux/termux.properties /data/data/com.learnprogramming.codecamp/files/home/.termux/
fi
