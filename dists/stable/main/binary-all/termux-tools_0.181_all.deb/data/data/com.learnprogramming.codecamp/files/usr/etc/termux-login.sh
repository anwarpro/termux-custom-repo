##
## This script is sourced by /data/data/com.learnprogramming.codecamp/files/usr/bin/login before executing shell.
##
